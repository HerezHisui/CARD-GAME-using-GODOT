extends Node2D

# We no longer need custom signals for hovering!
# The CardManager handles all hover detection via raycasts now.

func _ready() -> void:
	pass # You can leave this empty, or add individual card initialization here later

func _process(_delta: float) -> void:
	pass
