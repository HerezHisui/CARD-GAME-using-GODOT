extends Node2D

const COLLISION_MASK_CARD = 1

var screen_size
var card_being_dragged
var drag_offset: Vector2 = Vector2.ZERO
var last_hovered_card
var z_index_counter = 1

func _ready() -> void:
	screen_size = get_viewport_rect().size

func _process(delta: float) -> void:
	if card_being_dragged:
		var mouse_pos = get_global_mouse_position()
		var target_pos = mouse_pos + drag_offset
		card_being_dragged.global_position = Vector2(clamp(target_pos.x, 0, screen_size.x),
										clamp(target_pos.y, 0, screen_size.y))
	else:
		# NEW: Constantly check for hovers using the Z-index perfect raycast
		handle_hover_logic()

# NEW: Completely replaces the buggy signal system
func handle_hover_logic():
	var top_card = raycast_check_for_card()
	
	# If our mouse moved to a different card, or off all cards entirely
	if top_card != last_hovered_card:
		
		# 1. Un-highlight the previous card
		if last_hovered_card:
			last_hovered_card.scale = Vector2(0.3, 0.3)
		
		# 2. Highlight the newly detected top card
		if top_card:
			top_card.scale = Vector2(0.35, 0.35)
			z_index_counter += 1
			top_card.z_index = z_index_counter
			
		# 3. Save this card as our current hovered card
		last_hovered_card = top_card


func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			var card = raycast_check_for_card()
			if card:
				start_drag(card)
		else:
			if card_being_dragged:
				finish_drag()

func start_drag(card):
	card_being_dragged = card
	drag_offset = card.global_position - get_global_mouse_position()
	card.scale = Vector2(0.3, 0.3)

func finish_drag():
	card_being_dragged.scale = Vector2(0.35, 0.35)
	card_being_dragged = null

func raycast_check_for_card():
	var space_state = get_world_2d().direct_space_state
	var parameters = PhysicsPointQueryParameters2D.new()
	parameters.position = get_global_mouse_position()
	parameters.collide_with_areas = true
	parameters.collision_mask = COLLISION_MASK_CARD
	var result = space_state.intersect_point(parameters)
	
	if result.size() > 0:
		return get_card_with_highest_z_index(result)
	return null

func get_card_with_highest_z_index(cards):
	var highest_z_card = cards[0].collider.get_parent()
	var highest_z_index = highest_z_card.z_index
	
	for i in range(1, cards.size()):
		var current_card = cards[i].collider.get_parent()
		if current_card.z_index > highest_z_index:
			highest_z_card = current_card
			highest_z_index = current_card.z_index
			
	return highest_z_card
