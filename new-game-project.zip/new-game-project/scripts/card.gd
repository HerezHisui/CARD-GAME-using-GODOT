extends Control

const SNAP_DISTANCE := 200.0

var is_dragging := false
var drag_offset := Vector2.ZERO
var start_position := Vector2.ZERO
var in_hand := true

var card_name: String
var card_type: String
var attack: int
var health: int
var current_slot: Node2D = null

func _ready() -> void:
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)

func _on_mouse_entered() -> void:
	if not is_dragging:
		var tween = get_tree().create_tween().set_parallel(true)
		tween.tween_property(self, "scale", Vector2(0.26, 0.26), 0.1).set_ease(Tween.EASE_OUT)
		tween.tween_property(self, "rotation", 0.0, 0.1).set_ease(Tween.EASE_OUT)
		if current_slot and current_slot.is_in_group("hand_slots"):
			var target_y = current_slot.global_position.y - (size.y * 0.23 / 2.0) - 50.0
			tween.tween_property(self, "global_position:y", target_y, 0.1).set_ease(Tween.EASE_OUT)
		z_index = 50

func _on_mouse_exited() -> void:
	if not is_dragging:
		var tween = get_tree().create_tween().set_parallel(true)
		tween.tween_property(self, "scale", Vector2(0.2, 0.2), 0.1).set_ease(Tween.EASE_OUT)
		if current_slot:
			tween.tween_property(self, "rotation", current_slot.rotation, 0.1).set_ease(Tween.EASE_OUT)
			if current_slot.is_in_group("hand_slots"):
				var target_y = current_slot.global_position.y - (size.y * 0.2 / 2.0)
				tween.tween_property(self, "global_position:y", target_y, 0.1).set_ease(Tween.EASE_OUT)
		z_index = 0

func setup(data: Dictionary) -> void:
	card_name = data.get("name", "")
	card_type = data.get("type", "")
	attack = data.get("attack", 0)
	health = data.get("health", 0)

func is_slot_empty(slot: Node2D) -> bool:
	for card in get_tree().get_nodes_in_group("cards"):
		if card == self:
			continue
		if card.get("current_slot") == slot:
			return false
		var card_center = card.global_position + (card.size * card.scale / 2.0)
		if card_center.distance_to(slot.global_position) < 50.0:
			return false
	return true

func _on_gui_input(event: InputEvent) -> void:
	
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# Picks up the card
			is_dragging = true
			start_position = global_position
			drag_offset = get_global_mouse_position() - global_position
			z_index = 100
			
			var tween = get_tree().create_tween()
			tween.tween_property(self, "rotation", 0.0, 0.1).set_ease(Tween.EASE_OUT)
			
		else:
			is_dragging = false
			z_index = 50
			
			var card_center = global_position + (size * scale / 2.0)
			
			var closest_slot = null
			var closest_dist = SNAP_DISTANCE
			
			for slot in get_tree().get_nodes_in_group("slots"):
				if not is_slot_empty(slot):
					continue
					
				var dist = card_center.distance_to(slot.global_position)
				if dist < closest_dist:
					closest_dist = dist
					closest_slot = slot
			
			var target_pos = start_position
			var target_rot = 0.0
			if closest_slot:
				target_pos = closest_slot.global_position - (size * scale / 2.0)
				target_rot = closest_slot.rotation
				current_slot = closest_slot
			
			var tween = get_tree().create_tween().set_parallel(true)
			tween.tween_property(self, "global_position", target_pos, 0.2).set_ease(Tween.EASE_OUT)
			tween.tween_property(self, "rotation", target_rot, 0.2).set_ease(Tween.EASE_OUT)
			
			if get_parent().has_method("consolidate_hand"):
				get_parent().consolidate_hand()

	# 2. Detect Mouse Movement
	if event is InputEventMouseMotion and is_dragging:
		global_position = get_global_mouse_position() - drag_offset
