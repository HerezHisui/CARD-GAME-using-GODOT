extends Control

const SNAP_DISTANCE := 200.0

var is_dragging := false
var drag_offset := Vector2.ZERO
var start_position := Vector2.ZERO
var in_hand := true

var card_name: String
var card_type: String
var attack: int
var health: int
var current_slot: Node2D = null

func setup(data: Dictionary) -> void:
	card_name = data.get("name", "")
	card_type = data.get("type", "")
	attack = data.get("attack", 0)
	health = data.get("health", 0)

func is_slot_empty(slot: Node2D) -> bool:
	for card in get_tree().get_nodes_in_group("cards"):
		if card == self:
			continue
		if card.get("current_slot") == slot:
			return false
		var card_center = card.global_position + (card.size * card.scale / 2.0)
		if card_center.distance_to(slot.global_position) < 50.0:
			return false
	return true

func _on_gui_input(event: InputEvent) -> void:
	
	# 1. Detect Mouse Click
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# Picks up the card
			is_dragging = true
			start_position = global_position
			drag_offset = get_global_mouse_position() - global_position
			z_index = 100
			
		else:
			# Drop the card
			is_dragging = false
			z_index = 0
			
			var card_center = global_position + (size * scale / 2.0)
			
			# Find the closest slot within snap distance
			var closest_slot = null
			var closest_dist = SNAP_DISTANCE
			
			for slot in get_tree().get_nodes_in_group("slots"):
				if not is_slot_empty(slot):
					continue
					
				var dist = card_center.distance_to(slot.global_position)
				if dist < closest_dist:
					closest_dist = dist
					closest_slot = slot
			
			var target_pos = start_position
			if closest_slot:
				target_pos = closest_slot.global_position - (size * scale / 2.0)
				current_slot = closest_slot
			
			var tween = get_tree().create_tween()
			tween.tween_property(self, "global_position", target_pos, 0.2).set_ease(Tween.EASE_OUT)
			
			if get_parent().has_method("consolidate_hand"):
				get_parent().consolidate_hand()

	# 2. Detect Mouse Movement
	if event is InputEventMouseMotion and is_dragging:
		global_position = get_global_mouse_position() - drag_offset
