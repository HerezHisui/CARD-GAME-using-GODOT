extends Node

const StartScreen = preload("res://scenes/start_screen.tscn")
const Game = preload("res://scenes/game.tscn")

var current_scene = null

func _ready() -> void:
	show_start_screen()

func show_start_screen() -> void:
	if current_scene:
		current_scene.queue_free()
	current_scene = StartScreen.instantiate()
	current_scene.connect("play_pressed", _on_play_pressed)
	add_child(current_scene)

func _on_play_pressed() -> void:
	if current_scene:
		current_scene.queue_free()
	current_scene = Game.instantiate()
	add_child(current_scene)
  
 
