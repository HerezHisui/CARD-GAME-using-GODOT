extends Node2D

const CardScene = preload("res://scenes/card.tscn")

var deck: Array[Dictionary] = []

@onready var deck_label = $UI/DeckLabel
@onready var draw_button = $UI/DrawButton

func _ready() -> void:
	load_deck_from_json("res://data/starter_deck.json")
	deck.shuffle()
	update_deck_label()

func load_deck_from_json(path: String) -> void:
	var file = FileAccess.open(path, FileAccess.READ)
	if not file:
		print("Failed to open deck file: ", path)
		return
		
	var json = JSON.new()
	var error = json.parse(file.get_as_text())
	if error != OK:
		print("JSON Parse Error: ", json.get_error_message())
		return
		
	var card_definitions = json.data
	if typeof(card_definitions) == TYPE_ARRAY:
		for def in card_definitions:
			var count = def.get("count", 1)
			for i in range(count):
				var card_data = def.duplicate()
				card_data.erase("count")
				deck.append(card_data)

func get_hand_cards() -> Array:
	var hand_cards = []
	for card in get_tree().get_nodes_in_group("cards"):
		if card.get("is_dragging"):
			continue
		if card.get("current_slot") and card.current_slot.is_in_group("hand_slots"):
			hand_cards.append(card)
	return hand_cards

func draw_cards(count: int) -> void:
	var hand_cards = get_hand_cards()
	var hand_slots = get_tree().get_nodes_in_group("hand_slots")
	
	var draw_amount = min(count, hand_slots.size() - hand_cards.size())
	if draw_amount <= 0:
		print("Hand is full!")
		return
		
	var deck_spawn_pos = draw_button.global_position + (draw_button.size / 2.0)
	
	var newly_drawn = []
	for i in range(draw_amount):
		if deck.is_empty():
			print("Deck is empty!")
			break
			
		var card_data = deck.pop_back()
		var card_inst = CardScene.instantiate()
		
		add_child(card_inst)
		card_inst.add_to_group("cards")
		
		card_inst.setup(card_data)
		
		card_inst.current_slot = hand_slots[0]
		
		card_inst.scale = Vector2(0.1, 0.1)
		card_inst.global_position = deck_spawn_pos - (card_inst.size * 0.1 / 2.0)
		card_inst.rotation = 0.0
		card_inst.modulate.a = 0.0
		
		newly_drawn.append(card_inst)
		
	update_deck_label()
	arrange_hand_centered(newly_drawn)

func consolidate_hand() -> void:
	arrange_hand_centered([])

func arrange_hand_centered(newly_drawn: Array) -> void:
	var hand_slots = get_tree().get_nodes_in_group("hand_slots")
	hand_slots.sort_custom(func(a, b): return a.global_position.x < b.global_position.x)
	
	var all_cards = get_hand_cards()
	var old_cards = []
	
	for c in all_cards:
		if not c in newly_drawn:
			old_cards.append(c)
			
	old_cards.sort_custom(func(a, b): return a.global_position.x < b.global_position.x)
	
	var arranged_hand = old_cards + newly_drawn
	
	var start_index = int((hand_slots.size() - arranged_hand.size()) / 2.0)
	
	for i in range(arranged_hand.size()):
		var card = arranged_hand[i]
		var target_slot = hand_slots[start_index + i]
		
		card.set("current_slot", target_slot)
		
		var target_pos = target_slot.global_position - (card.size * 0.2 / 2.0)
		var target_rot = target_slot.rotation
		
		if card in newly_drawn:
			var delay = newly_drawn.find(card) * 0.15
			var tween = get_tree().create_tween()
			if delay > 0:
				tween.tween_interval(delay)
			tween.tween_property(card, "global_position", target_pos, 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
			tween.parallel().tween_property(card, "rotation", target_rot, 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
			tween.parallel().tween_property(card, "modulate:a", 1.0, 0.2)
			tween.parallel().tween_property(card, "scale", Vector2(0.2, 0.2), 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		else:
			var tween = get_tree().create_tween().set_parallel(true)
			tween.tween_property(card, "global_position", target_pos, 0.2).set_ease(Tween.EASE_OUT)
			tween.tween_property(card, "rotation", target_rot, 0.2).set_ease(Tween.EASE_OUT)

func update_deck_label() -> void:
	if deck_label:
		deck_label.text = "Deck: " + str(deck.size())

func _on_draw_button_pressed() -> void:
	draw_cards(1)
