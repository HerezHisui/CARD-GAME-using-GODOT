extends Node2D

const CardScene = preload("res://scenes/card.tscn")

var deck: Array[Dictionary] = []

@onready var deck_label = $UI/DeckLabel

func _ready() -> void:
	load_deck_from_json("res://data/starter_deck.json")
	deck.shuffle()
	update_deck_label()

func load_deck_from_json(path: String) -> void:
	var file = FileAccess.open(path, FileAccess.READ)
	if not file:
		print("Failed to open deck file: ", path)
		return
		
	var json = JSON.new()
	var error = json.parse(file.get_as_text())
	if error != OK:
		print("JSON Parse Error: ", json.get_error_message())
		return
		
	var card_definitions = json.data
	if typeof(card_definitions) == TYPE_ARRAY:
		for def in card_definitions:
			var count = def.get("count", 1)
			for i in range(count):
				var card_data = def.duplicate()
				card_data.erase("count")
				deck.append(card_data)


func get_empty_hand_slots() -> Array:
	var empty_slots = []
	var hand_slots = get_tree().get_nodes_in_group("hand_slots")
	hand_slots.sort_custom(func(a, b): return a.global_position.x < b.global_position.x)
	
	var cards = get_tree().get_nodes_in_group("cards")
	for slot in hand_slots:
		var is_empty = true
		for card in cards:
			if card.get("current_slot") == slot:
				is_empty = false
				break
			var card_center = card.global_position + (card.size * card.scale / 2.0)
			if card_center.distance_to(slot.global_position) < 50.0:
				is_empty = false
				break
		if is_empty:
			empty_slots.append(slot)
			
	return empty_slots

func draw_cards(count: int) -> void:
	var empty_slots = get_empty_hand_slots()
	
	var draw_amount = min(count, empty_slots.size())
	if draw_amount == 0:
		print("Hand is full!")
		return
		
	for i in range(draw_amount):
		if deck.is_empty():
			print("Deck is empty!")
			break
			
		var slot = empty_slots[i]
		var card_data = deck.pop_back()
		
		var card_inst = CardScene.instantiate()
		
		add_child(card_inst)
		card_inst.add_to_group("cards")
		
		card_inst.setup(card_data)
		card_inst.current_slot = slot
		
		card_inst.global_position = slot.global_position - (card_inst.size * card_inst.scale / 2.0)
		
	update_deck_label()

func consolidate_hand() -> void:
	var hand_slots = get_tree().get_nodes_in_group("hand_slots")
	hand_slots.sort_custom(func(a, b): return a.global_position.x < b.global_position.x)
	
	var hand_cards = []
	for card in get_tree().get_nodes_in_group("cards"):
		if card.get("current_slot") and card.current_slot.is_in_group("hand_slots") and not card.get("is_dragging"):
			hand_cards.append(card)
			
	#
	hand_cards.sort_custom(func(a, b): return a.global_position.x < b.global_position.x)
	
	for i in range(hand_cards.size()):
		var card = hand_cards[i]
		var target_slot = hand_slots[i]
		
		if card.get("current_slot") != target_slot:
			card.set("current_slot", target_slot)
			var target_pos = target_slot.global_position - (card.size * card.scale / 2.0)
			var tween = get_tree().create_tween()
			tween.tween_property(card, "global_position", target_pos, 0.2).set_ease(Tween.EASE_OUT)

func update_deck_label() -> void:
	if deck_label:
		deck_label.text = "Deck: " + str(deck.size())

func _on_draw_button_pressed() -> void:
	draw_cards(3)
